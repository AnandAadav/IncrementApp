//
//  ViewController.swift
//  MyIncrementApp
//
//  Created by Anand on 26/11/24.
//


import UIKit

class ViewController: UIViewController {

    var count = 0
    var countLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up the label
        countLabel = UILabel()
        countLabel.text = "Count: \(count)"
        countLabel.textAlignment = .center
        countLabel.frame = CGRect(x: 0, y: 200, width: 200, height: 50)
        countLabel.center = CGPoint(x: self.view.center.x, y: self.view.center.y - 50)
        self.view.addSubview(countLabel)

        // Set up the button
        let incrementButton = UIButton(type: .system)
        incrementButton.setTitle("Increment", for: .normal)
        incrementButton.frame = CGRect(x: 0, y: 0, width: 200, height: 50)
        incrementButton.center = self.view.center
        incrementButton.addTarget(self, action: #selector(incrementCount), for: .touchUpInside)
        self.view.addSubview(incrementButton)
    }

    @objc func incrementCount() {
        count += 1
        countLabel.text = "Count: \(count)"
    }
}
