#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/anand/Pictures/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/anand/Music/Increment App/increment_app"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=false"
export "TREE_SHAKE_ICONS=true"
export "PACKAGE_CONFIG=/Users/anand/Music/Increment App/increment_app/.dart_tool/package_config.json"
export "CODE_SIZE_DIRECTORY=build/flutter_size_02"
