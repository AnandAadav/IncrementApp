//
//  Increment.swift
//  
//
//  Created by Anand on 26/11/24.
//

import Foundation

@objc class Incrementer: NSObject {
    var count = 0

    @objc func incrementCount() -> Int {
        count += 1
        return count
    }
}

