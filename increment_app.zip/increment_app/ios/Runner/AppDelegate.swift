import UIKit
import Flutter



@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
    private var incrementer: Incrementer!
    private var incrementChannel: FlutterMethodChannel?

    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        let controller = window?.rootViewController as! FlutterViewController
        incrementChannel = FlutterMethodChannel(name: "com.example.increment", binaryMessenger: controller.binaryMessenger)
        
        incrementChannel?.setMethodCallHandler { (call, result) in
            if call.method == "incrementCount" {
                if self.incrementer == nil {
                    self.incrementer = Incrementer()
                }
                let newCount = self.incrementer.incrementCount()
                result(newCount)
            } else {
                result(FlutterMethodNotImplemented)
            }
        }

        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
}
