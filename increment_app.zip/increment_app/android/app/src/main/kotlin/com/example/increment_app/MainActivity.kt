package com.example.increment_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
