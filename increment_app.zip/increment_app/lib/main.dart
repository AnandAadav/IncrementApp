import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  static const platform = MethodChannel('com.example.increment');
  int _count = 0;

  Future<void> _incrementCount() async {
    try {
      final int newCount = await platform.invokeMethod('incrementCount');
      setState(() {
        _count = newCount;
      });
    } on PlatformException catch (e) {
      print("Failed to get count: '${e.message}'.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Increment App"),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text('Current count: $_count'),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _incrementCount,
                child: Text('Increment'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
